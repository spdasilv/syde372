clear all; close all;
clc;
rng default;
%% Generating Clusters
% Class A
mu_A = [5 10];
cov_A = [8 0; 0 4];
A = mvnrnd(mu_A, cov_A, 200);

% Class B
mu_B = [10 15];
cov_B = [8 0; 0 4];
B = mvnrnd(mu_B, cov_B, 200);

figure(1)
scatter(A(:,1), A(:,2), 'filled')
hold on;
scatter(B(:,1), B(:,2), 'filled')
hold on;
title('Plot for Class A and Class B')
legend('Class A','Class B')

%% Discretize the feature space
N = 20;
M = 25;
featureSpace = zeros(N,M);
% Closer to A - 1
% Closer to B - 0
for i=1:N
    for j = 1:M
        pos = [i j];
        d_pos_A = getDistance(pos, mu_A);
        d_pos_B = getDistance(pos, mu_B);
        
        min_d = min([d_pos_A  d_pos_B]);
        
        if min_d == d_pos_A
            featureSpace(i,j) = 1;
        elseif min_d == d_pos_B 
            featureSpace(i,j) = -1;
        end
    end
end


figure(3)
scatter(A(:,1), A(:,2), 'filled')
hold on;
scatter(B(:,1), B(:,2), 'filled')
hold on;
imcontour(featureSpace, 2)
hold on;
axis equal
title('Class A and B')