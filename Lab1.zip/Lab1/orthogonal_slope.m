function m = orthogonal_slope( m1, m2 )
    m = (m1(1) - m2(1))/ (m2(2) - m1(2));
end

