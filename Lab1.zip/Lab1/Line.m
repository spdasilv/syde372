% Formula for drawing a line with a slope and passing through a point on
% either side of a range
function [ pX, pY ] = Line( slope, x, y, range )
    % If the slope is parallel to Y-axis
    if (abs(slope) == Inf)
        pX = [x x];
        pY = [y - range y + range];
        return
    elseif (abs(slope) == 0) % If the slope is parallel to the X-axis
        pX = [x-range x+range];
        pY = [y y];
        return
    end
    
    pX = [x - range x + range];
    pY = [y - (range*slope) y + (range*slope)];
end

