clear all;
clc;
rng default;
%% Generating Clusters

% Class A
mu_A = [5 10];
cov_A = [8 0; 0 4];
A = mvnrnd(mu_A, cov_A, 200);

% Class B
mu_B = [10 15];
cov_B = [8 0; 0 4];
B = mvnrnd(mu_B, cov_B, 200);

figure(1)
scatter(A(:,1), A(:,2), 'filled')
hold on;
scatter(B(:,1), B(:,2), 'filled')
hold on;
title('Plot for Class A and Class B')
legend('Class A','Class B')
%%
% Class C
mu_C = [5 10];
cov_C = [8 4; 4 40];
C = mvnrnd(mu_C, cov_C, 100);

% Class D
mu_D = [15 10];
cov_D = [8 0; 0 8];
D = mvnrnd(mu_D, cov_D, 200);

% Class E
mu_E = [10 5];
cov_E = [10 -5; -5 20];
E = mvnrnd(mu_E, cov_E, 150);

figure(2)
scatter(C(:,1), C(:,2), 'filled')
hold on;
scatter(D(:,1), D(:,2), 'filled')
hold on;
scatter(E(:,1), E(:,2), 'filled')
hold on;
title('Plot for Class C, Class D, Class E')
legend('Class C','Class D', 'Class E')

%% MED - Minimum Euclidean Distance
% Class A and Class B
slope = orthogonal_slope( mu_A, mu_B );
mid = midpoint( mu_A, mu_B );
[ pX, pY ] = Line( slope, mid(1), mid(2), 10 );

figure;
scatter(A(:,1), A(:,2), 'filled')
hold on;
scatter(B(:,1), B(:,2), 'filled')
hold on;
plot(pX, pY)
hold on;
plot(mu_A, mu_B);
hold on;
axis equal
title('Plot for Class A and Class B')
legend('Class A','Class B', 'MED Boundary Line')
%%
% Class C, D, E
m_cd = orthogonal_slope(mu_C, mu_D);
m_ce = orthogonal_slope(mu_C, mu_E);
m_de = orthogonal_slope(mu_D, mu_E);

mid_cd = midpoint(mu_C, mu_D);
mid_ce = midpoint(mu_C, mu_E);
mid_de = midpoint(mu_D, mu_E);

[ pcd_X, pcd_Y ] = Line( m_cd, mid_cd(1), mid_cd(2), 10);
[ pce_X, pce_Y ] = Line( m_ce, mid_ce(1), mid_ce(2), 10 );
[ pde_X, pde_Y ] = Line( m_de, mid_de(1), mid_de(2), 10 );

figure(4)
scatter(C(:,1), C(:,2), 'filled')
hold on;
scatter(D(:,1), D(:,2), 'filled')
hold on;
scatter(E(:,1), E(:,2), 'filled')
hold on;
plot(pcd_X, pcd_Y)
hold on;
plot(pce_X, pce_Y)
hold on;
plot(pde_X, pde_Y)
hold on; plot([mu_C(1) mu_D(1)], [mu_C(2) mu_D(2)]); 
hold on; plot([mu_D(1) mu_E(1)], [mu_D(2) mu_E(2)]); 
hold on; plot([mu_C(1) mu_E(1)], [mu_C(2) mu_E(2)]);
hold on;
error_ellipse(cov_C, 'mu', mu_C, 'style', '-r')
hold on;
error_ellipse(cov_D, 'mu', mu_D, 'style', '-b')
hold on;
error_ellipse(cov_E, 'mu', mu_E, 'style', '-g')
hold on;
title('Plot for Class C, Class D, Class E')
legend('Class C','Class D', 'Class E', '-- CD --', ...
         '-- CE --', '-- DE --')
     
% QUESTION - How to plot SD contours?
%          - How to bifurcate the lines into proper regions?
%          - How to pick the eigenvalues and correspondig vectors?
%            Meaning does Max Eigen value always correspond to (1)

%% Generalized Euclidean Distance

[mu_trans_A, w_A] = WeightingGED( cov_A, mu_A );
[mu_trans_B, w_B] = WeightingGED( cov_B, mu_B );

A_trans = A*w_A;
B_trans = B*w_B;

slope_trans_ab = orthogonal_slope( mu_trans_A, mu_trans_B );
mid_trans_ab = midpoint( mu_trans_A, mu_trans_B );
[ pX_trans_ab, pY_trans_ab ] = Line( slope_trans_ab, mid_trans_ab(1), mid_trans_ab(2), 5 );

figure(5)
scatter(A_trans(:,1), A_trans(:,2), 'filled')
hold on;
scatter(B_trans(:,1), B_trans(:,2), 'filled')
hold on;
plot([mu_trans_A(1) mu_trans_B(1)], [mu_trans_A(2) mu_trans_B(2)], 'linewidth', 2)
hold on;
plot(pX_trans_ab, pY_trans_ab, 'linewidth', 1.25)
hold on;
axis equal
legend('A_t', 'B_t')

% repmat

