clear all; close all;
clc;
rng default;
%% Generating Clusters
mu_C = [5 10];
cov_C = [8 4; 4 40];
C = mvnrnd(mu_C, cov_C, 100);

% Class D
mu_D = [15 10];
cov_D = [8 0; 0 8];
D = mvnrnd(mu_D, cov_D, 200);

% Class E
mu_E = [10 5];
cov_E = [10 -5; -5 20];
E = mvnrnd(mu_E, cov_E, 150);

figure(2)
scatter(C(:,1), C(:,2), 'filled')
hold on;
scatter(D(:,1), D(:,2), 'filled')
hold on;
scatter(E(:,1), E(:,2), 'filled')
hold on;
title('Plot for Class C, Class D, Class E')
legend('Class C','Class D', 'Class E')

%% Discretize the feature space
N = 30;
M = 30;
featureSpace = zeros(N,M);
% Closer to A - 1
% Closer to B - 0
for i=1:N
    for j = 1:M
        pos = [i j];
        d_pos_A = getDistance(pos, mu_C);
        d_pos_B = getDistance(pos, mu_D);
        d_pos_C = getDistance(pos, mu_E);
        
        min_d = min([d_pos_A  d_pos_B  d_pos_C]);
        
        if min_d == d_pos_A
            featureSpace(i,j) = 1;
        elseif min_d == d_pos_B 
            featureSpace(i,j) = -1;
        elseif min_d == d_pos_C
            featureSpace(i,j) = 5;
        end
    end
end


figure(3)
scatter(C(:,1), C(:,2), 'filled')
hold on;
scatter(D(:,1), D(:,2), 'filled')
hold on;
scatter(E(:,1), E(:,2), 'filled')
hold on;
imcontour(featureSpace, 2)
hold on;
axis([0 25 -5 30])
title('Plot for Class C, Class D, Class E')
legend('Class C','Class D', 'Class E')