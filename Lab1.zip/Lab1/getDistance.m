function d = getDistance( p1, p2 )
    d = sqrt( (p2(1) - p1(1))^2 + (p2(2) - p1(2))^2 ) ;
end

